<?php
define('API_KEY', 'ad6b256f41dffeac14b4642b6d824ac2'); // OpenWeatherMap API key
define('API_BASE_URL', 'https://api.openweathermap.org/data/2.5/weather');

